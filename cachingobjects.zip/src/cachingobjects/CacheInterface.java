package cachingobjects;

import java.io.Serializable;

public interface CacheInterface {
    boolean cache( Serializable key,  Serializable value);
    Serializable get( Serializable key);
    Serializable delete( Serializable key);
    
}
