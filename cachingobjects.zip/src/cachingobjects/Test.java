/*
 @author Ekaterina A. Ivanova (C) 2013
 */

package cachingobjects;

public class Test implements java.io.Serializable {

    int intType = 6;
    double doubleType = -7.67d;
    String stringType = "hello";

    @Override
    public String toString() {
        return String.valueOf(intType) + "|" + String.valueOf(doubleType) + "|" + stringType;
    }
}